----------------------------------------------------------------------------
The following text files (exact file names as specified) should be included
The files contain example data. Please follow this format when submitting your assignment.
----------------------------------------------------------------------------

data.txt

	-Contains all the data that you generated
	-Arranged in 3 columns separated by commas
	-first column is Height, second column is Weight, third column is gender (0=male, 1=female)


sep_line_a.txt

	-Contains the weights that you generated for scenario a)

sep_line_b.txt

	-Contains the weights that you generated for scenario b)

